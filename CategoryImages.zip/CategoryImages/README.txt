Category Images
===============

A Vanilla Forums plugin that provides a specific category icon. A special thanks to digihub for the idea.

It is released under the GPLv3 and may be released under a different license with permission.

Install
=======
1.	Drop the CategoryImages folder into your vanilla/plugins folder.
2.	Enable the plugin in your dashboard
3.	Place your 32px wide category icons in the CategoryImages/design/images folder named <CategoryID>.png