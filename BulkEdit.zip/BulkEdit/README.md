Bulk Edit
=========
A Vanilla Forums plugin in that provides bulk user editing. It is designed to hook into the default user management dashboard.

It is released under the GPLv3 and may be released under a different license with permission. **It requires javascript to be enabled**

Install
=======
1.	Drop the BulkEdit folder into your vanilla/plugins folder.
2.	Enable the plugin in your dashboard
3.	Adjust the settings to your hearts content